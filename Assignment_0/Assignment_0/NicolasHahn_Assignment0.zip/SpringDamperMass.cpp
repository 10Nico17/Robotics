#include "SpringDamperMass.hpp"

// TODO Define your methods here

int SpringDamperMass::step() {

    _spring_mass_state.y=_spring_mass_state.y-(damping_coeff/MASS)*_spring_mass_state.y-(SPRING_CONST/MASS)*(_spring_mass_state.x-_pos_eqm);
    _spring_mass_state.x=_spring_mass_state.x+_spring_mass_state.y;
    _currentTime++;
    _spring_mass_states.push_back({_spring_mass_state.x, _spring_mass_state.y});
    return _currentTime;
}


