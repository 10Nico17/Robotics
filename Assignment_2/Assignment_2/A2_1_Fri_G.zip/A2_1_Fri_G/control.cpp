// controlDLL.cpp : Defines the entry point for the DLL application.

#include "servo.h"
#include "param.h"
#include "control.h"
// #include "UiAgent.h"
#include "PrVector.h"
#include "PrMatrix.h"
#include "Utils.h" // misc. utility functions, such as toRad, toDeg, etc.
#include <math.h>
#include <algorithm>
using std::min;
using std::max;

void PrintDebug(GlobalVariables& gv);


//Set a global variable that stores the start time 
struct Globalvariable {
    double t0;
};
Globalvariable gvariable;

struct CubicSpline {
    double t0, tf;
    PrVector a0, a1, a2, a3;
};
CubicSpline spline;

double computeT0(GlobalVariables& gv)
{
    //reset starting time
    gvariable.t0 = gv.curTime;
    return 0.0;
}
// *******************************************************************
// Initialization functions
// *******************************************************************

double computeTf(GlobalVariables& gv) {

    //Initial position 
    PrVector3 q0 = PrVector3(gv.q[0], gv.q[1], gv.q[2]);

    //Final position 
    PrVector3 q_f = PrVector3(gv.qd[0], gv.qd[1], gv.qd[2]);

    //calculate the span of the trajectory
    PrVector3 span = q_f - q0;

    std::vector<double> tf_values{
        std::abs(1.5 * (span[0] / gv.dqmax[0])), std::abs(1.5 * (span[1] / gv.dqmax[1])),
        std::abs(1.5 * (span[2] / gv.dqmax[2])),
        std::sqrt(std::abs(6 * span[0] / gv.ddqmax[0])),std::sqrt(std::abs(6 * span[1] / gv.ddqmax[1])),
        std::sqrt(std::abs(6 * span[2] / gv.ddqmax[2]))
    };

    // Find the highest tf value from all solutions
    double max_tf = *std::max_element(tf_values.begin(), tf_values.end());

    //total trajectory duration tf
    spline.tf = spline.t0 + max_tf;

    //Initial Velocity
    PrVector3 dq0 = PrVector3(gv.dq[0], gv.dq[1], gv.dq[2]);

    //calculate spline parameters
    spline.a0 = q0;
    spline.a1 = dq0;

    double t_delta = spline.tf - spline.t0;

    //Final Velocity at point c
    PrVector3 dq_f = PrVector3(0, 0, 0);

    spline.a2 = (3 * (span / pow(t_delta, 2))) - ((2 * dq0 + dq_f) / t_delta);
    spline.a3 = ((-2 * span) / pow(t_delta, 3)) + ((dq0 + dq_f) / pow(t_delta, 2));

    return 0.0;
}


void InitControl(GlobalVariables& gv)
{
    // This code runs before the first servo loop
}

void PreprocessControl(GlobalVariables& gv)
{
    // This code runs on every servo loop, just before the control law

    if ((gv.dof == 3) || (gv.dof == 6)) {
        // get the correct joint angles depending on the current mode:
        double q1, q2, q3;
        if (gv.dof == 3) {
            q1 = gv.q[0];
            q2 = gv.q[1];
            q3 = gv.q[2];
        }
        else if (gv.dof == 6) {
            q1 = gv.q[1];
            q2 = gv.q[2];
            q3 = gv.q[4];
        }

        // Variable that holds the torque exerted by gravity for each joint
        PrVector3 g123 = PrVector3(0, 0, 0);

        // Compute g123 here!

    //Splitting the Vector in 3 components 

        PrVector3 g1 = PrVector3(0, 0, 0);
        PrVector3 g2 = PrVector3(0, 0, 0);
        PrVector3 g3 = PrVector3(0, 0, 0);

        //Implementation of the calculations from task A 

        double r2 = 0.189738;

        //g1[1] = g1[2] = 0
        g1[0] = (M2 * R2 * cos(q1) * GRAVITY);

        //g2[2] = 0   

        g2[0] = ((M3 + M4 + M5) * (r2 * sin((q1 + q2)) + L2 * cos(q1)) * GRAVITY);
        g2[1] = ((M3 + M4 + M5) * r2 * sin((q1 + q2)) * GRAVITY);

        g3[0] = (M6 * (cos(q1) * L2 + sin((q1 + q2)) * L3 + R6 * sin((q1 + q2 + q3))) * GRAVITY);
        g3[1] = (M6 * (sin((q1 + q2)) * L3 + sin((q1 + q2 + q3)) * R6) * GRAVITY);
        g3[2] = (M6 * R6 * sin((q1 + q2 + q3)) * GRAVITY);

        //Sum of all the torques in a vector g123

        //corresponding torque for joint 1
        g123[0] = g1[0] + g2[0] + g3[0];

        //corresponding torque for joint 2
        g123[1] = g1[1] + g2[1] + g3[1];

        //corresponding torque for joint 3
        g123[2] = g1[2] + g2[2] + g3[2];

        // maps the torques to the right joint indices depending on the current mode:
        if (gv.dof == 3) {
            gv.G[0] = g123[0];
            gv.G[1] = g123[1];
            gv.G[2] = g123[2];
        }
        else if (gv.dof == 6) {
            gv.G[1] = g123[0];
            gv.G[2] = g123[1];
            gv.G[4] = g123[2];
        }
        // printing example, do not leave print inthe handed in solution 
        // printVariable(g123, "g123");
    }
    else {
        gv.G = PrVector(gv.G.size());
    }
}

void PostprocessControl(GlobalVariables& gv)
{
    // This code runs on every servo loop, just after the control law
}

void initFloatControl(GlobalVariables& gv)
{
    // Control Initialization Code Here
}

void initOpenControl(GlobalVariables& gv)
{
    // Control Initialization Code Here
}

void initNjholdControl(GlobalVariables& gv)
{
    // Control Initialization Code Here
}

void initJholdControl(GlobalVariables& gv)
{
    // Control Initialization Code Here
}

void initNjmoveControl(GlobalVariables& gv)
{
    // Control Initialization Code Here
}

void initJmoveControl(GlobalVariables& gv)
{
    // Control Initialization Code Here
}

void initNjgotoControl(GlobalVariables& gv)
{
    // Control Initialization Code Here
}

void initJgotoControl(GlobalVariables& gv)
{
    // Control Initialization Code Here
}

void initNjtrackControl(GlobalVariables& gv)
{
    // Calculate t0
    spline.t0 = gv.curTime;
    spline.tf = computeTf(gv);

}

void initJtrackControl(GlobalVariables& gv)
{
    // Control Initialization Code Here
}

void initNxtrackControl(GlobalVariables& gv)
{
    // Control Initialization Code Here
}

void initXtrackControl(GlobalVariables& gv)
{
    // Control Initialization Code Here
}

void initNholdControl(GlobalVariables& gv)
{
    // Control Initialization Code Here
}

void initHoldControl(GlobalVariables& gv)
{
    // Control Initialization Code Here
}

void initNgotoControl(GlobalVariables& gv)
{
    // Control Initialization Code Here
}

void initGotoControl(GlobalVariables& gv)
{
    // Control Initialization Code Here
}

void initNtrackControl(GlobalVariables& gv)
{
    // Control Initialization Code Here
}

void initTrackControl(GlobalVariables& gv)
{
    // Control Initialization Code Here
}

void initPfmoveControl(GlobalVariables& gv)
{
    // Control Initialization Code Here
}

void initLineControl(GlobalVariables& gv)
{
    // Control Initialization Code Here
}

void initProj1Control(GlobalVariables& gv)
{

    gv.qd[0] = 0.096;//set desired joint angles [rad]
    gv.qd[1] = 0.967;
    gv.qd[2] = -1.061;

    computeTf(gv);

}

void initProj2Control(GlobalVariables& gv)
{
    //get the reinitialized start time
    computeT0(gv);
}

void initProj3Control(GlobalVariables& gv)
{
    //get the reinitialized start time 
    computeT0(gv);
}


// *******************************************************************
// Control laws
// *******************************************************************

void noControl(GlobalVariables& gv)
{
}

void floatControl(GlobalVariables& gv)
{

    gv.tau = gv.G; //Integrating the torque vector to the Robot

    // gv.tau = ?
    // this only works on the real robot unless the function is changed to use cout
    // the handed in solution must not contain any printouts
    // PrintDebug(gv);
}

void openControl(GlobalVariables& gv)
{
    floatControl(gv);  // Remove this line when you implement this controller
}

void njholdControl(GlobalVariables& gv)
{
    floatControl(gv);  // Remove this line when you implement this controller
}

void jholdControl(GlobalVariables& gv)
{
    floatControl(gv);  // Remove this line when you implement this controller
}

void njmoveControl(GlobalVariables& gv)
{
    //Implementing the P Controller 
//gv.tau[0] refers to the torque for joint 1 , ...etc 

    gv.tau[0] = gv.kp[0] * (gv.qd[0] - gv.q[0]);
    gv.tau[1] = gv.kp[1] * (gv.qd[1] - gv.q[1]);
    gv.tau[2] = gv.kp[2] * (gv.qd[2] - gv.q[2]);

}

void jmoveControl(GlobalVariables& gv)
{
    floatControl(gv);  // Remove this line when you implement this controller
}

void njgotoControl(GlobalVariables& gv)
{
    //Implememtation of the P Controller with Gravity Compensation 
  //gv.tau[0] refers to the torque for joint 1 , ...etc 

    gv.tau[0] = gv.G[0] + (gv.kp[0] * (gv.qd[0] - gv.q[0]));
    gv.tau[1] = gv.G[1] + (gv.kp[1] * (gv.qd[1] - gv.q[1]));
    gv.tau[2] = gv.G[2] + (gv.kp[2] * (gv.qd[2] - gv.q[2]));


}

void jgotoControl(GlobalVariables& gv)
{

    //Implementation of the PD Contoller with Gravity Compensation 

  //gv.tau[0] refers to the torque for joint 1 , ...etc 

    gv.tau[0] = gv.G[0] + (gv.kp[0] * (gv.qd[0] - gv.q[0]) - (gv.kv[0] * gv.dq[0]));
    gv.tau[1] = gv.G[1] + (gv.kp[1] * (gv.qd[1] - gv.q[1]) - (gv.kv[1] * gv.dq[1]));
    gv.tau[2] = gv.G[2] + (gv.kp[2] * (gv.qd[2] - gv.q[2]) - (gv.kv[2] * gv.dq[2]));


}

void njtrackControl(GlobalVariables& gv)
{
    //cout << " ################## njtrackControl ########################" << endl;

    //cout << "gv.curTime: " << gv.curTime << endl;
    //cout << "spline.t0: " << spline.t0 << endl;
    //cout << "spline.tf: " << spline.tf << endl;
    double duration_1 = gv.curTime - spline.t0;

    if (gv.curTime > spline.tf)
    {
        floatControl(gv);

    }
    else {
        //TRACK POSITIONS AND VELOCITIES 

        //J1
        gv.qd[0] = spline.a0[0] + spline.a1[0] * duration_1 + spline.a2[0] * pow(duration_1, 2) + spline.a3[0] * pow(duration_1, 3);
        gv.dqd[0] = spline.a1[0] + 2 * spline.a2[0] * duration_1 + 3 * spline.a3[0] * pow(duration_1, 2);

        //J2 
        gv.qd[1] = spline.a0[1] + spline.a1[1] * duration_1 + spline.a2[1] * pow(duration_1, 2) + spline.a3[1] * pow(duration_1, 3);
        gv.dqd[1] = spline.a1[1] + 2 * spline.a2[1] * duration_1 + 3 * spline.a3[1] * pow(duration_1, 2);


        //J3
        gv.qd[2] = spline.a0[2] + spline.a1[2] * duration_1 + spline.a2[2] * pow(duration_1, 2) + spline.a3[2] * pow(duration_1, 3);
        gv.dqd[2] = spline.a1[2] + 2 * spline.a2[2] * duration_1 + 3 * spline.a3[2] * pow(duration_1, 2);


        //bringing in the PD Contoller with Gravity Compensation

        gv.tau[0] = gv.G[0] - (gv.kp[0] * (gv.q[0] - gv.qd[0]) + gv.kv[0] * (gv.dq[0] - gv.dqd[0]));

        gv.tau[1] = gv.G[1] - (gv.kp[1] * (gv.q[1] - gv.qd[1]) + gv.kv[1] * (gv.dq[1] - gv.dqd[1]));

        gv.tau[2] = gv.G[2] - (gv.kp[2] * (gv.q[2] - gv.qd[2]) + gv.kv[2] * (gv.dq[2] - gv.dqd[2]));

        //cout << "EXERTED TORQUES -- J1: " << gv.tau[0] << " J2: " << gv.tau[1] << " J3:" << gv.tau[2] << endl;
    }

}

void jtrackControl(GlobalVariables& gv)
{
    floatControl(gv);  // Remove this line when you implement this controller
}

void nxtrackControl(GlobalVariables& gv)
{
    floatControl(gv);  // Remove this line when you implement this controller
}

void xtrackControl(GlobalVariables& gv)
{
    floatControl(gv);  // Remove this line when you implement this controller
}

void nholdControl(GlobalVariables& gv)
{
    floatControl(gv);  // Remove this line when you implement this controller
}

void holdControl(GlobalVariables& gv)
{
    floatControl(gv);  // Remove this line when you implement this controller
}

void ngotoControl(GlobalVariables& gv)
{
    floatControl(gv);  // Remove this line when you implement this controller
}

void gotoControl(GlobalVariables& gv)
{
    floatControl(gv);  // Remove this line when you implement this controller
}

void ntrackControl(GlobalVariables& gv)
{
    floatControl(gv);  // Remove this line when you implement this controller
}

void trackControl(GlobalVariables& gv)
{
    floatControl(gv);  // Remove this line when you implement this controller
}

void pfmoveControl(GlobalVariables& gv)
{
    floatControl(gv);  // Remove this line when you implement this controller
}

void lineControl(GlobalVariables& gv)
{
    floatControl(gv);  // Remove this line when you implement this controller
}

void proj1Control(GlobalVariables& gv)
{
    //cout << "##################### proj1Control #####################" << endl;
    njtrackControl(gv);
}

void proj2Control(GlobalVariables& gv)
{
    //cout << "##################### proj2Control #####################" << endl;
    double duration_2 = gv.curTime - gvariable.t0;
    double r = 0.2;
    double omega = 2 * (M_PI / 5);
    double x_center = 0.6;
    double y_center = 0.35;

    //EE desired position space vector 
    gv.xd[0] = x_center + r * cos(omega * duration_2);
    gv.xd[1] = y_center - r * sin(omega * duration_2);

    //EE desired velocity space vector 
    gv.dxd[0] = omega * r * -sin(omega * duration_2);
    gv.dxd[1] = -r * omega * cos(omega * duration_2);

    //No motion in alpha
    gv.xd[2] = 0;
    gv.dxd[2] = 0;

    //cout << "gv.curTime: " << gv.curTime << ", x_d: " << gv.xd[0] << ", y_d: " << gv.xd[1] << endl;
    //cout << "gv.curTime: " << gv.curTime << ", dxd: " << gv.dxd[0] << ", dyd: " << gv.dxd[1] << endl;

    //OPERATIONAL SPACE CONTROLLER 
    double K = 1.0;

    //Equation reshaped for readability
    gv.tau = gv.G + K * gv.Jtranspose * (gv.kp * (gv.xd - gv.x) + gv.kv * (gv.dxd - gv.dx));
}

void proj3Control(GlobalVariables& gv)
{
    //cout << "##################### proj3Control #####################" << endl;
    double duration_3 = gv.curTime - gvariable.t0;
    double x_center = 0.6;
    double y_center = 0.35;
    double r = 0.2;

    //Blend region 1
    if (duration_3 < 5 || duration_3 == 5)
    {
        //EE desired position space vector 
        gv.xd[0] = x_center + r * cos((M_PI / 25) * pow(duration_3, 2));
        gv.xd[1] = y_center - r * sin((M_PI / 25) * pow(duration_3, 2));


        //EE desired velocity space vector
        gv.dxd[0] = -2 * (M_PI / 25) * r * duration_3 * sin((M_PI / 25) * pow(duration_3, 2));
        gv.dxd[1] = -2 * (M_PI / 25) * r * duration_3 * cos((M_PI / 25) * pow(duration_3, 2));


        //No motion in alpha
        gv.xd[2] = 0;
        gv.dxd[2] = 0;

    }

    //linear motion blend
    else if (duration_3 < 15 && duration_3 > 5)
    {

        //EE desired position space vector 
        gv.xd[0] = x_center - r * cos(2 * (M_PI / 5) * (duration_3 - 5));

        gv.xd[1] = y_center + r * sin(2 * (M_PI / 5) * (duration_3 - 5));


        //EE desired velocity space vector 
        gv.dxd[0] = 2 * (M_PI / 5) * r * sin(2 * (M_PI / 5) * (duration_3 - 5));

        gv.dxd[1] = 2 * (M_PI / 5) * r * cos(2 * (M_PI / 5) * (duration_3 - 5));

        //No motion in alpha
        gv.xd[2] = 0;
        gv.dxd[2] = 0;
    }

    //Blend region 2
    else if (duration_3 < 20 || duration_3 == 20)
    {
        double t_end = duration_3 - 20;

        //EE desired position space vector 
        gv.xd[0] = x_center + r * cos((M_PI / 25) * pow(t_end, 2));
        gv.xd[1] = y_center + r * sin((M_PI / 25) * pow(t_end, 2));


        //EE desired velocity space vector
        gv.dxd[0] = ((-2 * M_PI) / 25) * r * t_end * sin(-(M_PI / 25) * pow(t_end, 2));
        gv.dxd[1] = ((2 * M_PI) / 25) * r * t_end * cos((M_PI / 25) * pow(t_end, 2));


        //No motion in alpha
        gv.xd[2] = 0;
        gv.dxd[2] = 0;

    }

    //OPERATIONAL SPACE CONTROLLER 
    double K = 1.0;

    //Equation reshaped for readability
    gv.tau = gv.G + K * gv.Jtranspose * (gv.kp * (gv.xd - gv.x) + gv.kv * (gv.dxd - gv.dx));
}

// *******************************************************************
// Debug function
// *******************************************************************

void PrintDebug(GlobalVariables& gv)
{
    // Replace this code with any debug information you'd like to get
    // when you type "pdebug" at the prompt.
    printf("This sample code prints the torque and mass\n");
    gv.tau.display("tau");
    gv.A.display("A");
}

#ifdef WIN32
// *******************************************************************
// XPrintf(): Replacement for printf() which calls ui->VDisplay()
// whenever the ui object is available.  See utility/XPrintf.h.
// *******************************************************************

int XPrintf(const char* fmt, ...)
{
    int returnValue;
    va_list argptr;
    va_start(argptr, fmt);

    returnValue = vprintf(fmt, argptr);

    va_end(argptr);
    return returnValue;
}
#endif //#ifdef WIN32

/********************************************************

END OF DEFAULT STUDENT FILE

ADD HERE ALL STUDENT DEFINED AND AUX FUNCTIONS

*******************************************************/
