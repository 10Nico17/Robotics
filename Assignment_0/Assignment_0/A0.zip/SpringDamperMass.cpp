#include "SpringDamperMass.hpp"

// TODO Define your methods here
