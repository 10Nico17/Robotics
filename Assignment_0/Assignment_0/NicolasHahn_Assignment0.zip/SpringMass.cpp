#include "SpringMass.hpp"

// define gravity constant
const double SpringMass::GRAVITY = 10;
const double SpringMass::SPRING_CONST = 7;
const double SpringMass::MASS = 30;

// TODO SpringMass constructor
SpringMass::SpringMass(double pos_init, double vel_init,
                       double pos_eqm, double vel_eqm) {

    _pos_init=pos_init;
    _vel_init=vel_init;

    _pos_eqm=pos_eqm;
    _vel_eqm=vel_eqm;

    _currentTime=0;  

    //set the state to the intial values 
    _spring_mass_state.x=_pos_init;   //time step zero
    _spring_mass_state.y=_vel_init;   //time step zero

    //vector to save all states over time 
    _spring_mass_states.push_back({_spring_mass_state.x, _spring_mass_state.y});

}

// TODO SpringMass simulation step
// increase and return the current time stamp
int SpringMass::step() {

    _spring_mass_state.y=_spring_mass_state.y-(SPRING_CONST/MASS)*(_spring_mass_state.x-_pos_eqm);
    _spring_mass_state.x=_spring_mass_state.x+_spring_mass_state.y;
    _currentTime++;

    _spring_mass_states.push_back({_spring_mass_state.x, _spring_mass_state.y});

    return _currentTime;
}

// TODO SpringMass configuration getter
bool SpringMass::getConfiguration(int t, Vec2d& state) const {
    if(t>_currentTime){
        // cout << "Error: wrong time stamp" << endl;
        return false;
    }

    state.x=_spring_mass_states[t].x;
    state.y=_spring_mass_states[t].y;

    return true;           
}

// TODO SpringMass current simulation time getter
int SpringMass::getCurrentSimulationTime() const {
    return _currentTime;
}


SpringMass::~SpringMass(){

}
