#include "localization/ParticleFilter.h"
#include "localization/Util.h"

#include "tf/tf.h"

using namespace std;

ParticleFilter::ParticleFilter(int numberOfParticles) {
  this->numberOfParticles = numberOfParticles;

  // initialize particles
  for (int i = 0; i < numberOfParticles; i++) {
    this->particleSet.push_back(new Particle());
  }

  // this variable holds the estimated robot pose
  this->bestHypothesis = new Particle();

  // at each correction step of the filter only the laserSkip-th beam of a scan
  // should be integrated
  this->laserSkip = 5;

  // distance map used for computing the likelihood field
  this->distMap = NULL;
}

ParticleFilter::~ParticleFilter() {
  // delete particles
  for (int i = 0; i < numberOfParticles; i++) {
    Particle *p = this->particleSet[i];
    delete p;
  }

  this->particleSet.clear();

  if (this->likelihoodField)
    delete[] this->likelihoodField;

  delete this->bestHypothesis;

  if (this->distMap)
    delete[] this->distMap;
}

int ParticleFilter::getNumberOfParticles() { return this->numberOfParticles; }

std::vector<Particle *> *ParticleFilter::getParticleSet() {
  return &(this->particleSet);
}

void ParticleFilter::initParticlesUniform() {
  // get map properties
  int mapWidth, mapHeight;
  double mapResolution;
  this->getLikelihoodField(mapWidth, mapHeight, mapResolution);

  // TODO: here comes your code
  for (int i = 0; i < this->numberOfParticles; i++) {
    this->getParticleSet()->at(i)->x =
        Util::uniformRandom(.0, mapWidth * mapResolution);
    this->getParticleSet()->at(i)->y =
        Util::uniformRandom(.0, mapHeight * mapResolution);
    this->getParticleSet()->at(i)->theta = Util::uniformRandom(.0, 2 * M_PI);
    this->getParticleSet()->at(i)->weight = 1.0 / this->numberOfParticles;
  }
  this->sumOfParticleWeights = 1.0;
}

void ParticleFilter::initParticlesGaussian(double mean_x, double mean_y,
                                           double mean_theta, double std_xx,
                                           double std_yy, double std_tt) {
  // TODO: here comes your code
  for (int i = 0; i < this->getParticleSet()->size(); i++) {
    this->getParticleSet()->at(i)->x = Util::gaussianRandom(mean_x, std_xx);
    this->getParticleSet()->at(i)->y = Util::gaussianRandom(mean_y, std_yy);
    this->getParticleSet()->at(i)->theta =
        Util::normalizeTheta(Util::gaussianRandom(mean_theta, std_tt));
    this->getParticleSet()->at(i)->weight = 1.0 / this->numberOfParticles;
  }
  this->sumOfParticleWeights = 1.0;
}

/**
 *  Initializes the likelihood field as our sensor model.
 */
void ParticleFilter::setMeasurementModelLikelihoodField(
    const nav_msgs::OccupancyGrid &map, double zRand, double sigmaHit) {
  ROS_INFO("Creating likelihood field for laser range finder...");

  // create the likelihood field - with the same discretization as the occupancy
  // grid map
  this->likelihoodField = new double[map.info.height * map.info.width];
  this->likelihoodFieldWidth = map.info.width;
  this->likelihoodFieldHeight = map.info.height;
  this->likelihoodFieldResolution = map.info.resolution;

  // calculates the distance map and stores it in member variable 'distMap'
  // for every map position it contains the distance to the nearest occupied
  // cell.
  calculateDistanceMap(map);

  // Here you have to create your likelihood field
  // HINT0: sigmaHit is given in meters. You have to take into account the
  // resolution of the likelihood field to apply it. HINT1: You will need the
  // distance map computed 3 lines above HINT2: You can visualize it in the
  // map_view when clicking on "show likelihood field" and "publish all". HINT3:
  // Storing probabilities in each cell between 0.0 and 1.0 might lead to
  // round-off errors, therefore it is good practice to convert the
  // probabilities into log-space, i.e. storing log(p(x,y)) in each cell. As a
  // further advantage you can simply add the log-values in your sensor model,
  // when you weigh each particle according the scan, instead of multiplying the
  // probabilities, because: log(a*b) = log(a)+log(b).

  // TODO: here comes your code
  double zHit = 1.0 - zRand;
  for (int x = 0; x < map.info.width; x++) {
    for (int y = 0; y < map.info.height; y++) {
      int index = x + y * map.info.width;
      double distance = this->distMap[index];
      double sigmaWithResolution = sigmaHit / map.info.resolution;

      double pHit = Util::gaussian(distance, sigmaWithResolution, 0.0);
      double probability = zRand + (zHit * pHit);

      this->likelihoodField[index] = log(probability);
    }
  }
  ROS_INFO("...DONE creating likelihood field!");
}

void ParticleFilter::calculateDistanceMap(const nav_msgs::OccupancyGrid &map) {
  // calculate distance map = distance to nearest occupied cell
  distMap = new double[likelihoodFieldWidth * likelihoodFieldHeight];
  int occupiedCellProbability = 90;
  // initialize with max distances
  for (int x = 0; x < likelihoodFieldWidth; x++) {
    for (int y = 0; y < likelihoodFieldHeight; y++) {
      distMap[x + y * likelihoodFieldWidth] = 32000.0;
    }
  }
  // set occupied cells next to unoccupied space to zero
  for (int x = 0; x < map.info.width; x++) {
    for (int y = 0; y < map.info.height; y++) {
      if (map.data[x + y * map.info.width] >= occupiedCellProbability) {
        bool border = false;
        for (int i = -1; i <= 1; i++) {
          for (int j = -1; j <= 1; j++) {
            if (!border && x + i >= 0 && y + j >= 0 &&
                x + i < likelihoodFieldWidth && y + j < likelihoodFieldHeight &&
                (i != 0 || j != 0)) {
              if (map.data[x + i + (y + j) * likelihoodFieldWidth] <
                      occupiedCellProbability &&
                  map.data[x + i + (y + j) * likelihoodFieldWidth] >= 0)
                border = true;
            }
            if (border)
              distMap[x + i + (y + j) * likelihoodFieldWidth] = 0.0;
          }
        }
      }
    }
  }
  // first pass -> SOUTHEAST
  for (int x = 0; x < likelihoodFieldWidth; x++)
    for (int y = 0; y < likelihoodFieldHeight; y++)
      for (int i = -1; i <= 1; i++)
        for (int j = -1; j <= 1; j++)
          if (x + i >= 0 && y + j >= 0 && x + i < likelihoodFieldWidth &&
              y + j < likelihoodFieldHeight && (i != 0 || j != 0)) {
            double v = distMap[x + i + (y + j) * likelihoodFieldWidth] +
                       ((i * j != 0) ? 1.414 : 1);
            if (v < distMap[x + y * likelihoodFieldWidth]) {
              distMap[x + y * likelihoodFieldWidth] = v;
            }
          }

  // second pass -> NORTHWEST
  for (int x = likelihoodFieldWidth - 1; x >= 0; x--)
    for (int y = likelihoodFieldHeight - 1; y >= 0; y--)
      for (int i = -1; i <= 1; i++)
        for (int j = -1; j <= 1; j++)
          if (x + i >= 0 && y + j >= 0 && x + i < likelihoodFieldWidth &&
              y + j < likelihoodFieldHeight && (i != 0 || j != 0)) {
            double v = distMap[x + i + (y + j) * likelihoodFieldWidth] +
                       ((i * j != 0) ? 1.414 : 1);
            if (v < distMap[x + y * likelihoodFieldWidth]) {
              distMap[x + y * likelihoodFieldWidth] = v;
            }
          }
}

double *ParticleFilter::getLikelihoodField(int &width, int &height,
                                           double &resolution) {
  width = this->likelihoodFieldWidth;
  height = this->likelihoodFieldHeight;
  resolution = this->likelihoodFieldResolution;

  return this->likelihoodField;
}

/**
 *  A generic measurement integration method that invokes some specific
 * observation model. Maybe in the future, we add some other model here.
 */
void ParticleFilter::measurementModel(
    const sensor_msgs::LaserScanConstPtr &laserScan) {
  likelihoodFieldRangeFinderModel(laserScan);
}

/**
 *  Method that implements the endpoint model for range finders.
 *  It uses a precomputed likelihood field to weigh the particles according to
 * the scan and the map.
 */
void ParticleFilter::likelihoodFieldRangeFinderModel(
    const sensor_msgs::LaserScanConstPtr &laserScan) {

  // TODO: here comes your code
  this->sumOfParticleWeights = 0;

  for (int i = 0; i < this->numberOfParticles; i++) {
    double particleX = this->getParticleSet()->at(i)->x;
    double particleY = this->getParticleSet()->at(i)->y;
    double particleTheta = this->getParticleSet()->at(i)->theta;

    double scan_probability = 0;

    for (int j = 0; j < laserScan->ranges.size(); j += this->laserSkip) {
      double beamRange = laserScan->ranges[j];

      if (beamRange <= laserScan->range_max &&
          beamRange >= laserScan->range_min) {

        double beamTheta =
            laserScan->angle_min + laserScan->angle_increment * j;

        double xToAdd =
            beamRange *
            std::cos(Util::normalizeTheta(beamTheta + particleTheta));

        double yToAdd =
            beamRange *
            std::sin(Util::normalizeTheta(beamTheta + particleTheta));

        int x = (particleX + xToAdd) / this->likelihoodFieldResolution;
        int y = (particleY + yToAdd) / this->likelihoodFieldResolution;

        if (x < this->likelihoodFieldWidth && y < this->likelihoodFieldHeight &&
            y > 0 && x > 0) {
          scan_probability =
              scan_probability +
              this->likelihoodField[x + y * this->likelihoodFieldWidth];
        } else {
	  // reduce the weight when laser scan endpoints are supposed
	  // to lie outside the map
          scan_probability = scan_probability - 1;
        }
      }
    }
    this->getParticleSet()->at(i)->weight = std::exp(scan_probability);
    // Used to normalize the weights
    this->sumOfParticleWeights =
        this->sumOfParticleWeights + this->getParticleSet()->at(i)->weight;
  }
  // Normalize the weights back to 1
  for (int i = 0; i < this->numberOfParticles; i++) {
    if (this->sumOfParticleWeights > 0) {
      this->getParticleSet()->at(i)->weight =
          this->getParticleSet()->at(i)->weight / this->sumOfParticleWeights;
    }
  }
}

void ParticleFilter::setMotionModelOdometry(double alpha1, double alpha2,
                                            double alpha3, double alpha4) {
  this->odomAlpha1 = alpha1;
  this->odomAlpha2 = alpha2;
  this->odomAlpha3 = alpha3;
  this->odomAlpha4 = alpha4;
}

/**
 *  A generic motion integration method that invokes some specific motion
 * model. Maybe in the future, we add some other model here.
 */
void ParticleFilter::sampleMotionModel(double oldX, double oldY,
                                       double oldTheta, double newX,
                                       double newY, double newTheta) {
  sampleMotionModelOdometry(oldX, oldY, oldTheta, newX, newY, newTheta);
}

/**
 *  Method that implements the odometry-based motion model.
 */
void ParticleFilter::sampleMotionModelOdometry(double oldX, double oldY,
                                               double oldTheta, double newX,
                                               double newY, double newTheta) {
  // TODO: here comes your code
  double delta_trans = std::sqrt(((newX - oldX) * (newX - oldX)) +
                                 ((newY - oldY) * (newY - oldY)));

  double delta_rotation_1 =
      Util::normalizeTheta(std::atan2(newY - oldY, newX - oldX) - oldTheta);
  double delta_rotation_2 =
      Util::normalizeTheta(newTheta - oldTheta - delta_rotation_1);

  for (int i = 0; i < this->getParticleSet()->size(); i++) {
    double delta_rotation_1_with_error =
        delta_rotation_1 +
        Util::gaussianRandom(0, this->odomAlpha1 * std::abs(delta_rotation_1) +
                                    this->odomAlpha2 * delta_trans);
    double delta_trans_with_error =
        delta_trans +
        Util::gaussianRandom(
            0, this->odomAlpha3 * delta_trans +
                   this->odomAlpha4 *
                       Util::normalizeTheta(std::abs(delta_rotation_1) +
                                            std::abs(delta_rotation_2)));
    double delta_rotation_2_with_error =
        delta_rotation_2 +
        Util::gaussianRandom(0, this->odomAlpha1 * std::abs(delta_rotation_2) +
                                    this->odomAlpha2 * delta_trans);

    Particle *particle = this->getParticleSet()->at(i);

    particle->x = particle->x +
                  delta_trans_with_error *
                      std::cos(particle->theta + delta_rotation_1_with_error);
    particle->y = particle->y +
                  delta_trans_with_error *
                      std::sin(particle->theta + delta_rotation_1_with_error);
    particle->theta =
        Util::normalizeTheta(particle->theta + delta_rotation_1_with_error +
                             delta_rotation_2_with_error);
  }
}

/**
 *  The stochastic importance resampling.
 */
void ParticleFilter::resample() {
  // TODO: here comes your code
  //

  double numberOfParticles = this->getNumberOfParticles();
  std::vector<Particle> newParticleSet(numberOfParticles);
  std::vector<double> c(numberOfParticles);
  std::vector<double> u(numberOfParticles);
  double currentWeight = 0;
  double bestWeight = 0;

  c[0] = this->getParticleSet()->at(0)->weight;
  u[0] =
      Util::uniformRandom(0, 1.0 / numberOfParticles);
  for (int i = 1; i < numberOfParticles; i++) {
    c[i] = c[i - 1] + this->getParticleSet()->at(i)->weight; // Generate cdf
  }

  int i = 0;
  for (int j = 0; j < numberOfParticles; j++) { // Draw samples

    while (u[j] > c[i]) { // skip until next threshold
      i = i + 1;
    }
    Particle *particle = this->getParticleSet()->at(i);
    newParticleSet[j].x = particle->x;
    newParticleSet[j].y = particle->y;
    newParticleSet[j].theta = particle->theta;
    newParticleSet[j].weight = 1.0 / numberOfParticles;
    u[j + 1] = u[j] + 1 / numberOfParticles; // increment threshold

    // Update robot position 
    currentWeight = this->getParticleSet()->at(i)->weight;
    if (currentWeight > bestWeight) {
      bestWeight = currentWeight;
      this->bestHypothesis = this->getParticleSet()->at(i);
    }
  }

  // Update all particles
  for (int i = 0; i < numberOfParticles; i++) {
    Particle *particle = this->getParticleSet()->at(i);
    particle->x = newParticleSet[i].x;
    particle->y = newParticleSet[i].y;
    particle->theta = newParticleSet[i].theta;
    particle->weight = newParticleSet[i].weight;
  }
}

Particle *ParticleFilter::getBestHypothesis() { return this->bestHypothesis; }

// added for convenience
int ParticleFilter::computeMapIndex(int width, int height, int x, int y) {
  return x + y * width;
}
