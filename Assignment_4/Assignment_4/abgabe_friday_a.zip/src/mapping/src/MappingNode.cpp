// A mapping node for educational purposes

// roscpp
#include "ros/ros.h"

// Messages and services that we need
#include "sensor_msgs/LaserScan.h"
#include "nav_msgs/GetMap.h"
#include "nav_msgs/OccupancyGrid.h"
#include "std_srvs/Empty.h"

// For transform support
#include "tf/transform_listener.h"
#include "tf/message_filter.h"
#include "message_filters/subscriber.h"

// someone was lazy here...
#define SWAP(a, b)  {a ^= b; b ^= a; a ^= b;}

using namespace std;

class MappingNode {

public:
	MappingNode(ros::NodeHandle n);
	~MappingNode();

private:
	ros::NodeHandle nodeHandle;

	// we use the OccupancyGrid structure representing the reflection map
	nav_msgs::OccupancyGrid map;

	// subscribe to laser, use a msg_filter to ensure that we can associate an odometry pose with the scan
	tf::TransformListener tfListener;
	message_filters::Subscriber<sensor_msgs::LaserScan> laserScanSubscriber;
	tf::MessageFilter<sensor_msgs::LaserScan> laserScanFilter;

	// in order to visualize the map, we have to publish it
	ros::Publisher mapPublisher;
	ros::ServiceServer mapService;

	// Message and service callbacks
	void laserReceived( const sensor_msgs::LaserScanConstPtr& laser_scan );
	bool mapRequested( nav_msgs::GetMap::Request& req, nav_msgs::GetMap::Response& res );

	///////////////////////////////////////////////////
	// <helpful methods>

	// implementation of the bresenham algorithm: http://en.wikipedia.org/wiki/Bresenham%27s_line_algorithm
	//  returns all points from the starting point (x0, y0) and end point (x1, y1)
	//  starting and end point are included in the returned result.
	vector<pair<int, int> > bresenhamLine( int x0, int y0, int x1, int y1 );

	/**
	 * @brief Updates the zell values based on the hits and misses, on the line between robot x,y and laserHit x,y
	 * 
	 * @param robotX: x position of robot
	 * @param robotY: y position of robot
	 * @param laserHitX: x position where the laser hit something
	 * @param laserHitY: y position where the laser hit something
	 * 
	 * @return nothing
	*/
    void updateCellValues(int robotX, int robotY, int laserHitX, int laserHitY);
	
	// use this method to update the reflection map
	void updateReflectionMapValue(int x, int y, double value);

	// </helpful methods>
	///////////////////////////////////////////////////
	
	///////////////////////////////////////////////////
    // vectors with the hits and misses count for each cell
    vector<vector<int> > hits;
    vector<vector<int> > misses;
	// </your declarations>
	///////////////////////////////////////////////////
};

MappingNode::MappingNode(ros::NodeHandle n) :
	nodeHandle(n),
	laserScanSubscriber(nodeHandle, "scan", 5),
	laserScanFilter(laserScanSubscriber, tfListener, "odom", 5)
{
	// initialize map meta data
	// map is 20 x 20 meters, resolution is 0.02 meters per grid cell
	this->map.info.resolution = 0.02;
	this->map.info.width = 1000;
	this->map.info.height = 1000;
	this->map.info.origin.position.x = -this->map.info.resolution * this->map.info.width / 2.0;
	this->map.info.origin.position.y = -this->map.info.resolution * this->map.info.height / 2.0;
	this->map.info.origin.position.z = 0.0;
	this->map.info.origin.orientation.x = 0.0;
	this->map.info.origin.orientation.y = 0.0;
	this->map.info.origin.orientation.z = 0.0;
	this->map.info.origin.orientation.w = 1.0;
	this->map.data.resize( this->map.info.width * this->map.info.height );

	// initialize map
	for (unsigned int i = 0; i < this->map.info.width; i++) {
		for (unsigned int j = 0; j < this->map.info.height; j++) {
			int index = j*this->map.info.height + i;
			this->map.data[index] = -1; // -1 means unknown
		}
	}
	///////////////////////////////////////////////////
	// Initialise the hits and misses arrays with zero
    hits.resize(this->map.info.width, vector<int>(this->map.info.height, 0));
    misses.resize(this->map.info.width, vector<int>(this->map.info.height, 0));
	///////////////////////////////////////////////////

	// subscribe to laser scan
	laserScanFilter.registerCallback( boost::bind( &MappingNode::laserReceived, this, _1 ) );
//	laserScanFilter.setTolerance(ros::Duration(0.01));

	// publish the map we're building
	this->mapPublisher = this->nodeHandle.advertise<nav_msgs::OccupancyGrid>( "map", 2 );
	this->mapService = this->nodeHandle.advertiseService( "map", &MappingNode::mapRequested, this );

	// publish the unknown map for the first time
	this->mapPublisher.publish( this->map );
}

MappingNode::~MappingNode() {
}


void MappingNode::updateCellValues(int robotX, int robotY, int laserHitX, int laserHitY) {
    vector<pair<int, int> > cells = bresenhamLine(robotX, robotY, laserHitX, laserHitY);

	// loop through all the cells, between the robot position and the laser hit
    for(pair<int, int> cell : cells) {
        int currCellX = cell.first;
        int currCellY = cell.second;

        if (currCellX > hits.size() || currCellY > hits[currCellX].size()){
            ROS_WARN("Cell Coordinate Out of Bounce: x: %d, y: %d", currCellX, currCellY);
            continue;
        }

        // update hits and misses
		#define ACCURACY 0
        if (currCellX <= laserHitX+ACCURACY && currCellX >= laserHitX-ACCURACY
            && currCellY <= laserHitY+ACCURACY && currCellY >= laserHitY-ACCURACY){
            hits[currCellX][currCellY]++;
        } else {
            misses[currCellX][currCellY]++;
        }

		// check if hits or misses exceed inter_max to avoid an overflow
		if (hits[currCellX][currCellY] > INT_MAX || misses[currCellX][currCellY] > INT_MAX){
			hits[currCellX][currCellY] /= 2;
			misses[currCellX][currCellY] /= 2;
		}

		// calculate the occupancy grid value and update the reflection map
        double occuppancyGridValue = (double) hits[currCellX][currCellY] / (double)(hits[currCellX][currCellY] + misses[currCellX][currCellY]);
        double reflectionMapValue = (occuppancyGridValue < 0.5) ? 0 : 1;
        updateReflectionMapValue(currCellX, currCellY, reflectionMapValue);
    }
}


// 1. get the laser scan data: range_min, range_max, ranges[], angle_min, angle_max, angle_increment
// 2. for each laser beam, compute the reflection grid update value, discard ranges < range_min and > range_max
// 3. use the bresenham algorithm to get all the cells that are crossed by the laser beam
// 4. for each returned cell, update the hits and misses count
void MappingNode::laserReceived( const sensor_msgs::LaserScanConstPtr& laserScan ) {
	// what's the robot's odometry when this scan was taken?
	tf::Stamped<tf::Pose> ident( tf::Transform( tf::createIdentityQuaternion(), tf::Vector3(0,0,0) ), laserScan->header.stamp, "laser" );
	tf::Stamped<tf::Pose> odomPose;
	try {
		this->tfListener.transformPose( "odom", ident, odomPose );
	}
	catch( tf::TransformException e ) {
		ROS_WARN( "Failed to compute odom pose, skipping scan (%s)", e.what() );
		return;
	}

    // transform pose of robot to map coordinates
    int robotX = odomPose.getOrigin().x() / this->map.info.resolution + this->map.info.width / 2;
    int robotY = odomPose.getOrigin().y() / this->map.info.resolution + this->map.info.height / 2;
    double robotTheta = tf::getYaw( odomPose.getRotation() );

    ///////////////////////////////////////////////////
    int numRanges = laserScan->ranges.size();
	float rangeMin = laserScan->range_min;
	float rangeMax = laserScan->range_max;
	float angleMin = laserScan->angle_min;
	float angle_increment = laserScan->angle_increment;

	// create array to store the current laser scan ranges
	float * ranges = (float *) calloc(numRanges, sizeof(float));
	copy(begin(laserScan->ranges), end(laserScan->ranges), ranges);

	// loop through all the laser beams
    for(int rangeIter = 0; rangeIter < numRanges; rangeIter++) {
        float range = ranges[rangeIter];
        if(range < rangeMin || range > rangeMax)
            continue;

        // get the laser beam coordinates
        float angle = robotTheta + angleMin + rangeIter * angle_increment;
        float laserX = range*cos(angle);
        float laserY = range*sin(angle);

        // convert to map coordinates
        int laserHitX = laserX/this->map.info.resolution + robotX;
        int laserHitY = laserY/this->map.info.resolution + robotY;

		// check if the coordinates are in the map
        if (laserHitX > this->map.info.width || laserHitY > this->map.info.height){
            ROS_INFO("Coordinates not in map: x: %d, y: %d | laserX: %f, laserY: %f", laserHitX, laserHitY, laserX, laserY);
            continue;
        }

        updateCellValues(robotX, robotY, laserHitX, laserHitY);
    }

	free(ranges);
	///////////////////////////////////////////////////


	// publish result
	this->map.header.stamp = ros::Time::now();
	this->map.header.frame_id = "/odom";
	this->mapPublisher.publish( this->map );
}

void MappingNode::updateReflectionMapValue(int i, int j, double value) {
	int index = j*this->map.info.width + i;
	this->map.data[index] = 100*value; // *100 is just for better visibility in visualization
}

vector<pair<int, int> > MappingNode::bresenhamLine( int x0, int y0, int x1, int y1 ) {
	vector<pair<int, int> > result;

	bool steep = abs(y1 - y0) > abs(x1 - x0);

	if( steep ) {
		SWAP( x0, y0 );
		SWAP( x1, y1 );
	}
	if( x0 > x1 ) {
		SWAP( x0, x1 );
		SWAP( y0, y1 );
	}

	int deltax = x1 - x0;
	int deltay = abs(y1 - y0);
	int error = deltax / 2;
	int y = y0;
	int ystep = ( y0 < y1 ) ? 1 : -1;

	for( int x = x0; x <= x1; x++ ) {
		if ( steep ) {
			// cell (y,x) is crossed
			result.push_back(pair<int, int>(y, x));
		} else {
			// cell (x,y) is crossed
			result.push_back(pair<int, int>(x, y));
		}

		error = error - deltay;
		if( error < 0 ) {
			y += ystep;
			error += deltax;
		}
	}
	
	return result;
}

bool MappingNode::mapRequested( nav_msgs::GetMap::Request &request, nav_msgs::GetMap::Response &response ) {
	if( this->map.info.width && this->map.info.height )	{
		this->map.header.stamp = ros::Time::now();
		response.map = this->map;
		return true;
	}
	else
		return false;
}


int main( int argc, char** argv ) {
	ros::init( argc, argv, "mapper" );
	ros::NodeHandle nh;

	MappingNode mn( nh );

	ros::spin();

	return 0;
}
