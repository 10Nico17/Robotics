#include "YourPlanner.h"
#include <rl/plan/SimpleModel.h>
#include <random>
#include <iostream>
#include <rl/plan/Viewer.h>

YourPlanner::YourPlanner() :
  RrtConConBase()
{
}

YourPlanner::~YourPlanner()
{
}

::std::string
YourPlanner::getName() const
{
  return "Your Planner";
}

void
YourPlanner::choose(::rl::math::Vector& chosen)
{
  //your modifications here
  chosen = this->sampler->generateCollisionFree();
  // RrtConConBase::choose(chosen);
}

RrtConConBase::Vertex 
YourPlanner::connect(Tree& tree, const Neighbor& nearest, const ::rl::math::Vector& chosen)
{
  //Do first extend step

  ::rl::math::Real distance = nearest.second;
  ::rl::math::Real step = distance;

  bool reached = false;

  if (step <= this->delta)
  {
    reached = true;
  }
  else
  {
    step = this->delta;
  }

  ::rl::plan::VectorPtr last = ::std::make_shared< ::rl::math::Vector >(this->model->getDof());

  // Avoid potential division byy 0 and later Segmentation Fault
  if(distance < epsilon){
    return NULL;
  }
  // move "last" along the line q<->chosen by distance "step / distance"
  this->model->interpolate(*tree[nearest.first].q, chosen, step / distance, *last);

  this->model->setPosition(*last);
  this->model->updateFrames();

  if (this->model->isColliding())
  {
    // Increase the count of collisions detected when trying to connect to this node
    tree[nearest.first].numberOfCollisions++;
    return NULL;
  }

  ::rl::math::Vector next(this->model->getDof());

  while (!reached)
  {
    //Do further extend step

    distance = this->model->distance(*last, chosen);
    step = distance;

    if (step <= this->delta)
    {
      reached = true;
    }
    else
    {
      step = this->delta;
    }

    // move "next" along the line last<->chosen by distance "step / distance"
    this->model->interpolate(*last, chosen, step / distance, next);

    this->model->setPosition(next);
    this->model->updateFrames();

    if (this->model->isColliding())
    {
      tree[nearest.first].numberOfCollisions++;
      break;
    }

    *last = next;
  }

  // "last" now points to the vertex where the connect step collided with the environment.
  // Add it to the tree
  Vertex connected = this->addVertex(tree, last);
  this->addEdge(nearest.first, connected, tree);
  return connected;
  //your modifications here
  //return RrtConConBase::connect(tree, nearest, chosen);
}

RrtConConBase::Vertex 
YourPlanner::extend(Tree& tree, const Neighbor& nearest, const ::rl::math::Vector& chosen)
{
  //your modifications here
  return RrtConConBase::extend(tree, nearest, chosen);
}

bool
YourPlanner::solve()
{
  this->time = ::std::chrono::steady_clock::now();
  // Define the roots of both trees
  this->begin[0] = this->addVertex(this->tree[0], ::std::make_shared< ::rl::math::Vector >(*this->start));
  this->begin[1] = this->addVertex(this->tree[1], ::std::make_shared< ::rl::math::Vector >(*this->goal));

  Tree* a = &this->tree[0];
  Tree* b = &this->tree[1];

  ::rl::math::Vector chosen(this->model->getDof());

  // Define Gaussian starting standarddev and growthrate
  double gaussianStddev     = 0.5;
  double gaussianStddevStep = 1.0;

  // Define number of passes after which the maximum standard deviation should be increased
  // Most number of samples checked to find a solution was 1350. Set to 2000 just in case.
  ::std::size_t loopLimit = 2000;
  // Initialize loopCounter with 0
  ::std::size_t loopCounter = 0;

  // Variables needed for the additiona significant point extension
  // // Create a sample-configuration in the middle of the workspace. First initialize with all 0
  // ::rl::math::Vector middleOfWorkspace(this->model->getDof());
  // for(size_t i = 0; i < this->model->getDof();i++) {
  //   middleOfWorkspace(i) = 0;
  // }
  // // Set the Y-Axis of the configuration to the height of the first joint of the puma
  // middleOfWorkspace(2) = 0.66;

  while ((::std::chrono::steady_clock::now() - this->time) < this->duration)
  {
    // If below loop limit, increment
    if(loopCounter < loopLimit){
      loopCounter++;
    }
    // If at or above loopLimit, increment gaussianStddev by gaussianStdddevStep
    else {
      gaussianStddev += gaussianStddevStep;
      // Reset loopCounter
      loopCounter = 0;
    }
    //First grow tree a and then try to connect b.
    //then swap roles: first grow tree b and connect to a.
    for (::std::size_t j = 0; j < 2; ++j)
    // for (::std::size_t j = 0; j < 4; ++j)
    {
      //Sample random config around current root
      if(j == 0){
        chosen = this->generateGaussian(*this->start, gaussianStddev);
      }
      else {
        chosen = this->generateGaussian(*this->goal, gaussianStddev);
      }    

      // Attempt at reducing runtime in worst-case; runtime reduction in average case was not worth it.
      // switch(j){
      //   case 0:
      //     chosen = this->generateGaussian(*this->start, gaussianStddev);
      //     break;
      //   case 1:
      //     chosen = this->generateGaussian(*this->goal, gaussianStddev);
      //     break;
      //   default:
      //     chosen = this->generateGaussian(middleOfWorkspace, gaussianStddev, modifier);
      // }

      Neighbor aNearest;

      //Find the nearest neighbour in the tree
      aNearest = this->modifiedNearest(*a, chosen);

      //Do a CONNECT step from the nearest neighbour to the sample
      Vertex aConnected = this->connect(*a, aNearest, chosen);

      //If a new node was inserted tree a
      if (NULL != aConnected)
      {
        // Try a CONNECT step form the other tree to the sample
        Neighbor bNearest = this->modifiedNearest(*b, chosen);
        Vertex bConnected = this->connect(*b, bNearest, *(*a)[aConnected].q);

        if (NULL != bConnected)
        {
          //Test if we could connect both trees with each other
          if (this->areEqual(*(*a)[aConnected].q, *(*b)[bConnected].q))
          {
            this->end[0] = &this->tree[0] == a ? aConnected : bConnected;
            this->end[1] = &this->tree[1] == b ? bConnected : aConnected;
            return true;
          }
        }
      }

      //Swap the roles of a and b
      using ::std::swap;
      swap(a, b);
    }

  }

  return false;
  //your modifications here
  //return RrtConConBase::solve();
}

/**
 * SOLVE WITH GAUSS-SAMPLER AND ADAPTIVE DYNAMIC DOMAIN
*/
// bool
// YourPlanner::solve()
// {
//   this->time = ::std::chrono::steady_clock::now();
//   // Define the roots of both trees
//   this->begin[0] = this->addVertex(this->tree[0], ::std::make_shared< ::rl::math::Vector >(*this->start));
//   this->begin[1] = this->addVertex(this->tree[1], ::std::make_shared< ::rl::math::Vector >(*this->goal));

//   Tree* a = &this->tree[0];
//   Tree* b = &this->tree[1];

//   ::rl::math::Vector chosen(this->model->getDof());

//   // Radius expansion factor
//   ::rl::math::Real alpha = 0.05;
//   // Lower bound for the Radius
//   ::rl::math::Real lowerBound  = 2.0;
//   // Initial domain of the vertex
//   ::rl::math::Real radius = 20.0;

//   while ((::std::chrono::steady_clock::now() - this->time) < this->duration)
//   {
//     //First grow tree a and then try to connect b.
//     //then swap roles: first grow tree b and connect to a.
//     for (::std::size_t j = 0; j < 2; ++j)
//     {
//       // Sample a random configuration. Used for the gauss-sampling implementation, reduction in nodes but no runtime speedup.
//       // this->choose(chosen);

//       Neighbor aNearest;

//       do
//       {
//        this->choose(chosen);
// 			  aNearest = this->modifiedNearest(*a, chosen);
//       }      
//        while(aNearest.second > (*a)[aNearest.first].radius);

//       //Do a CONNECT step from the nearest neighbour to the sample
//       Vertex aConnected = this->connect(*a, aNearest, chosen);

//       //If a new node was inserted tree a
//       if (NULL != aConnected)
//       {
//         if((*a)[aNearest.first].radius < ::std::numeric_limits<::rl::math::Real>::max()){
//           (*a)[aNearest.first].radius *= (1 + alpha);
//         }
//         // Try a CONNECT step form the other tree to the sample
//         Neighbor bNearest = this->modifiedNearest(*b, chosen);
//         Vertex bConnected = this->connect(*b, bNearest, *(*a)[aConnected].q);

//         if (NULL != bConnected)
//         {
//           //Test if we could connect both trees with each other
//           if (this->areEqual(*(*a)[aConnected].q, *(*b)[bConnected].q))
//           {
//             this->end[0] = &this->tree[0] == a ? aConnected : bConnected;
//             this->end[1] = &this->tree[1] == b ? bConnected : aConnected;
//             return true;
//           }
//         }
//       }
//       else {
//         if((*a)[aNearest.first].radius < ::std::numeric_limits<::rl::math::Real>::max()){
//            (*a)[aNearest.first].radius *= (1 - alpha);
//            (*a)[aNearest.first].radius = ::std::max(lowerBound, (*a)[aNearest.first].radius);
//          }
//         else {
//          (*a)[aNearest.first].radius = radius;
//         }
//       }

//       //Swap the roles of a and b
//       using ::std::swap;
//       swap(a, b);
//     }

//   }

//   return false;
//   //your modifications here
//   //return RrtConConBase::solve();
// }

YourPlanner::Neighbor
YourPlanner::modifiedNearest(const Tree& tree, const ::rl::math::Vector& chosen)
{
  //create an empty pair <Vertex, distance> to return
  Neighbor p(Vertex(), (::std::numeric_limits< ::rl::math::Real >::max)());

  //Iterate through all vertices to find the nearest neighbour
  for (VertexIteratorPair i = ::boost::vertices(tree); i.first != i.second; ++i.first)
  {
    //check if the node is exhausted; if it is not, proceed
    //std::cout << "first Node collisions: " << tree[*i.first].numberOfCollisions << std::endl;
    //if(tree[*i.first].numberOfCollisions < EXHAUSTED){
    //std::cout << "Exhausted: " << tree[*i.first].numberOfCollisions << std::endl;
    //}
    ::rl::math::Real d = this->model->transformedDistance(chosen, *tree[*i.first].q);

    if (d < p.second)
    {
      p.first = *i.first;
      p.second = d;
    } 
  }


  // Compute the square root of distance
  p.second = this->model->inverseOfTransformedDistance(p.second);

  p.second > tree[p.first].radius;

  return p;
}

::rl::math::Vector
YourPlanner::generateGaussian(::rl::math::Vector sampleq, double stddev){
  ::rl::math::Vector result(this->model->getDof());
  std::random_device rd;
  std::mt19937 gen(rd());
  for(::std::size_t i = 0; i < this->model->getDof(); ++i){
    std::normal_distribution<double> dist(sampleq(i), stddev); 
      result(i) = dist(gen);
  }

  return result;
}

::rl::math::Vector
YourPlanner::generateGaussian(::rl::math::Vector sampleq, double stddev, double modifier){
  ::rl::math::Vector result(this->model->getDof());
  std::random_device rd;
  std::mt19937 gen(rd());
  for(::std::size_t i = 0; i < this->model->getDof(); ++i){
    std::normal_distribution<double> dist(sampleq(i), stddev); 
      // 
      result(i) = dist(gen) * (1 + modifier);
  }

  return result;
}
