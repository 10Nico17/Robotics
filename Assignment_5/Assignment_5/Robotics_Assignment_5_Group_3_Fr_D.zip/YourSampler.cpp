#include <chrono>
#include <rl/plan/SimpleModel.h>
#include "YourSampler.h"
#include <iostream>

namespace rl
{
    namespace plan
    {
        YourSampler::YourSampler() :
            Sampler(),
            randDistribution(0, 1),
            randEngine(::std::random_device()()),
            stddev(nullptr),
            gaussDistribution(0, 1),
            ratio(static_cast<::rl::math::Real>(5) / static_cast<::rl::math::Real>(6))
        {
        }

        YourSampler::~YourSampler()
        {
        }

        ::rl::math::Vector
        YourSampler::generate()
        {
            // Our template code performs uniform sampling.
            // You are welcome to change any or all parts of the sampler.
            // BUT PLEASE MAKE SURE YOU CONFORM TO JOINT LIMITS,
            // AS SPECIFIED BY THE ROBOT MODEL!

            ::rl::math::Vector sampleq(this->model->getDof());

            ::rl::math::Vector maximum(this->model->getMaximum());
            ::rl::math::Vector minimum(this->model->getMinimum());

            for (::std::size_t i = 0; i < this->model->getDof(); ++i)
            {
                sampleq(i) = minimum(i) + this->rand() * (maximum(i) - minimum(i));
            }

            // It is a good practice to generate samples in the
            // the allowed configuration space as done above.
            // Alternatively, to make sure generated joint 
            // configuration values are clipped to the robot model's 
            // joint limits, you may use the clip() function like this: 
            // this->model->clip(sampleq);

            return sampleq;
        }

        ::rl::math::Vector
        YourSampler::generateCollisionFree() {
            // StandardDeviation-Vector for testing
            this->stddev = new ::rl::math::Vector(this->model->getDof());
            for (::std::size_t i = 0; i < this->model->getDof(); ++i)
            {
                (*this->stddev)(i) = 3.0;
            }
                // ::rl::math::Vector bridgeSample(this->model->getDof());
                ::rl::math::Vector gaussSample(this->model->getDof());

                while(true){
                    // Aquire uniform sample
                    ::rl::math::Vector uniformSample = this->generate();

                    // Collision test
                    this->model->setPosition(uniformSample);
                    this->model->updateFrames();
                    if(this->model->isColliding()){
                        
                    }
                    // If the uniform sample did not collide, test if nearby sample collides.
                    else{
                        // Fill gaussSample vector with gaussian distributed values
                        for (::std::size_t i = 0; i < this->model->getDof(); ++i)
						{
							gaussSample(i) = this->gauss();
						}
                        // Generate sample close to the uniform sample from  the two sample vectors and sttdev
                        ::rl::math::Vector nearbySample = this->model->generatePositionGaussian(gaussSample, uniformSample, *this->getStddev());

                        // Ensure nearbySample is within robot model limits
                        // this->model->clip(nearbySample);

                        // Check if nearbySample is colliding
                        this->model->setPosition(nearbySample);
                        this->model->updateFrames();
                        if(this->model->isColliding()){
                            return uniformSample;
                        }

                    }
                }
            }
        

        ::rl::math::Vector
        YourSampler::generateGaussian(::rl::math::Vector sampleq, double stddev){
        ::rl::math::Vector result(this->model->getDof());
        std::random_device rd;
        std::mt19937 gen(rd());
        for(::std::size_t i = 0; i < this->model->getDof(); ++i){
            std::normal_distribution<double> dist(sampleq(i), stddev); 
            result(i) = dist(gen);
        }

        return result;
        }

        ::std::uniform_real_distribution< ::rl::math::Real>::result_type
        YourSampler::rand()
        {
            return this->randDistribution(this->randEngine);
        }

        ::std::normal_distribution<::rl::math::Real>::result_type 
        YourSampler::gauss(){
            return this->gaussDistribution(this->randEngine);
        }

        ::rl::math::Real
		YourSampler::getRatio() const
		{
			return this->ratio;
		}
		
		void
		YourSampler::setRatio(const ::rl::math::Real& ratio)
		{
			this->ratio = ratio;
		}

        void
        YourSampler::seed(const ::std::mt19937::result_type& value)
        {
            this->randEngine.seed(value);
        }

        ::rl::math::Vector*
		YourSampler::getStddev() const
		{
			return this->stddev;
		}
		
		void
		YourSampler::setStddev(::rl::math::Vector* stddev)
		{
			this->stddev = stddev;
		}
    }
}

