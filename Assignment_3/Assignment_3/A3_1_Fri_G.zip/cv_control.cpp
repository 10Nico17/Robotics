#include "cv_control.h"

#include <opencv2/imgproc.hpp>
#include <opencv2/core/types_c.h>

using namespace cv;
using namespace std;

// Parameters for Visual Servoing
float f;					// Focal length in pixel
float img_width;			// width of image sensor in pixel
float img_height;			// height of image sensor in pixel
float diameter_real;		// real diameter of the circle
float diameter_desired_px;	// desired diameter of the circle in pixels
float dt;					// Time step
float t0;                  // how fast the velocity controller should converge
int   hcd_min_distance;
PrVector3 desired_s_opencvf;

void initVisualServoing(float _f, float _img_width, float _img_height, float _diameter_real, float _diameter_desired_px, float _dt, PrVector3 _desired_s_opencvf)
{
    f = _f;
    img_width = _img_width;
    img_height = _img_height;
    diameter_real = _diameter_real;
    diameter_desired_px = _diameter_desired_px;
    dt = _dt;
    desired_s_opencvf = _desired_s_opencvf;
    t0 = 0.3;   //time constant for controller convergence. Smaller values result in higher velocities. Transforms an error into a velocity
    hcd_min_distance = 2000;
}

/*****************************************************************************************************************/
/* YOUR WORK STARTS HERE!!! GROUP 1_Fri_G */

/** 
* findCircleFeature
* Find circles in the image using the OpenCV Hough Circle detector
*
* Input parameters:
*  img: the camera image, you can print text in it with 
* 	    putText(img,"Hello World",cvPoint(0,12),FONT_HERSHEY_SIMPLEX,0.5,CV_RGB(0,0,255))
*	    see http://opencv.willowgarage.com/documentation/cpp/drawing_functions.html#cv-puttext
*
*  backproject: grayscale image with high values where the color of the image is like the selected color.
*
* Output:
*  crcl: as a result of this function you should write the center and radius of the detected circle into crcl
*/
bool findCircleFeature(Mat& img, Mat &backproject, Circle& crcl)
{
    vector<Vec3f> circles;

    cv::GaussianBlur(backproject, backproject, Size(15, 15), 1, 1);
  
    //Fine-tuning parameters for cv::HoughCircles
    int radius_min = 10;
    int radius_max = 500;

    cv::HoughCircles(backproject, circles, HOUGH_GRADIENT, 1, backproject.rows / 8, 60, 50, radius_min, radius_max);

    if (circles != std::vector<cv::Vec3f>{})
    {
        //DETECTION -->center and radius are stored in member structs 
        crcl.radius = circles[0][2];
        crcl.center = Point2f(circles[0][0], circles[0][1]);
        
        
        //DRAW CIRCLE
        Point center(cvRound(circles[0][0]), cvRound(circles[0][1]));
        int radius = cvRound(circles[0][2]);

        // CIRCLE CENTER
        circle(img, center, 3, Scalar(0, 255, 0), FILLED, cv::LINE_AA, 0);

        // CIRCLE OUTLINE 
        circle(img, center, radius, Scalar(0, 255,0), 2, cv::LINE_AA, 0);

        return true;
    }
    else
    {
        return false;
    }
}

/**
* getImageJacobianCFToFF
* Compute the Image Jacobian to map from 
* camera velocity in Camera Frame to feature velocities in Feature Frame
* 
* You should use getImageJacobianFFToCF in controlRobot
*
* Input parameters:
*  u and v: the current center of the circle in feature frame [pixels]
*  z: the estimated depth of the circle [meters]
*  f: the focal length [pixels]
*  diameter: the real diameter of the circle [meters]
*
* Output:
*  Jv: assign your image 3x3 Jacobian.
*/
void getImageJacobianCFToFF(PrMatrix3 &Jv, float u, float v, float z, float f, float diameter)
{
   //FIRST ROW
    Jv[0][0] = -f / z;
    Jv[0][1] = 0;
    Jv[0][2] = u / z;
    
    //SECOND ROW
    Jv[1][0] = 0;
    Jv[1][1] = -f / z;
    Jv[1][2] = v / z;
   
    //THIRD ROW
    Jv[2][0] = 0;
    Jv[2][1] = 0;
    Jv[2][2] =(f * diameter)/ pow(z, 2);

}

/**
* estimateCircleDepth
* Estimates and returns the depth of the circle
*
* Input parameters:
*  f: the focal length [pixels]
*  diameter: the real diameter of the circle [meters]
*  crcl: the parameters of the detected circle in the image
*
* Output return:
*  depth of the circle wrt the camera [meters]
*/
float estimateCircleDepth(float f, float diameter, Circle &crcl)
{
    float depth = (diameter * f) / (2 * crcl.radius);
    return depth;
  
}

/**
* transformFromOpenCVFToFF
* Transform a feature vector from openCV frame (origin in upper left corner of the image) to feature frame (origin at the center of the image)
*
* Input parameter:
*  vector_opencvf: feature vector defined in opencv frame
*
* Output:
*  vector_ff: feature vector defined in feature frame
*/
void transformFromOpenCVFToFF(PrVector3 vector_opencvf, PrVector3& vector_ff) 
{
    //Translatiion of x, y, z coordinates
    vector_ff[0] = vector_opencvf[0] - img_width / 2;
    vector_ff[1] = vector_opencvf[1] - img_height / 2;
    vector_ff[2] = vector_opencvf[2];

}

/**
* transformVelocityFromCFToEEF
* Transform the desired velocity vector from camera frame to end-effector frame
* You can hard code this transformation according to the fixed transformation between the camera and the end effector
* (see the sketch in your assignment)
*
* Input parameter:
*  vector_cf: velocity vector defined in camera frame
*
* Output:
*  vector_eef: velocity vector defined in end-effector frame
*/
void transformVelocityFromCFToEEF(PrVector3 vector_cf, PrVector3& vector_eef)
{
    //Transformation of x, y , z coordinates
    vector_eef[0] = -vector_cf[1];
    vector_eef[1] = vector_cf[0];
    vector_eef[2] = vector_cf[2];

}

/**
* transformVelocityFromEEFToBF
* Transform the desired velocity vector from end-effector frame to base frame
* You cannot hard code this transformation because it depends of the current orientation of the end-effector wrt the base
* Make use of the current state of the robot x (the pose of the end-effector in base frame coordinates)
*
* Input parameters:
*  x_current_bf: current state of the robot - pose of the end-effector in base frame coordinates
*  vector_eef: velocity vector defined in end-effector frame
*
* Output:
*  vector_bf: velocity vector defined in base frame
*/

void transformVelocityFromEEFToBF(PrVector x_current_bf, PrVector3 vector_eef, PrVector3& vector_bf)
{
    double R_q[3][3]{}; // Defining a 3x3 matrix

    //Parameters to be set to x_current_bf last 4 elements
    double q0, q1, q2, q3;

    q0 = x_current_bf[3];
    q1 = x_current_bf[4];
    q2 = x_current_bf[5];
    q3 = x_current_bf[6];


    // First row of the rotation matrix
    R_q[0][0] = 2 * (pow(q0, 2) + pow(q1, 2)) - 1;
    R_q[0][1] = 2 * (q1 * q2 - q0 * q3);
    R_q[0][2] = 2 * (q1 * q3 + q0 * q2);

    // Second row of the rotation matrix 
    R_q[1][0] = 2 * (q1 * q2 + q0 * q3);
    R_q[1][1] = 2 * (pow(q0, 2) + pow(q2, 2)) - 1;
    R_q[1][2] = 2 * (q2 * q3 - q0 * q1);

    // Third row of the rotation matrix 
    R_q[2][0] = 2 * (q1 * q3 - q0 * q2);
    R_q[2][1] = 2 * (q2 * q3 + q0 * q1);
    R_q[2][2] = 2 * (pow(q0, 2) + pow(q3, 2)) - 1;

    //compute the transformation with velocity vector
    vector_bf[0] = R_q[0][0] * vector_eef[0] + R_q[0][1] * vector_eef[1] + R_q[0][2] * vector_eef[2];
    vector_bf[1] = R_q[1][0] * vector_eef[0] + R_q[1][1] * vector_eef[1] + R_q[1][2] * vector_eef[2];
    vector_bf[2] = R_q[2][0] * vector_eef[0] + R_q[2][1] * vector_eef[1] + R_q[2][2] * vector_eef[2];

}

/*
* controlRobot
* This function computes the command to be send to the robot using Visual Servoing so that the robot tracks the circle
*
* Here you should:
* - compute the error in feature frame
* - compute the circle depth
* - compute the image jacobian from feature frame in camera frame
* - compute the desired ee velocity in feature frame
* - compute the desired ee velocity in camera frame
* - compute the desired ee velocity in ee frame
* - compute the desired ee velocity in base frame
* - compute the step in the direction of the desired ee velocity in base frame
* - form the comand to be sent to the robot (previous pose + computed step)
*
* The function will only be called if findCircleFeature returns true (if a circle is detected in the image)
*
* Input parameters:
*  crcl: the parameters of the detected circle in the image
*  x:	current robot configuration in operational space (7 dof: 3 first values are position, 4 last values is orientation quaternion)
*  img: the camera image for drawing debug text
*
* Output:
*  cmdbuf: should contain the command for the robot controler, for example: 
*			"goto 0.0 0.0 90.0 0.0 0.0 0.0"
*/

void controlRobot(Circle& crcl, PrVector &x, Mat& img, char *cmdbuf)
{
    if (crcl.radius == 0) {
        sprintf(cmdbuf,"float");
        return;
    }

    PrVector3 current_s_opencvf;
    current_s_opencvf[0] = crcl.center.x;
    current_s_opencvf[1] = crcl.center.y;
    current_s_opencvf[2] = 2*crcl.radius;

    PrVector3 desired_s_ff;
    transformFromOpenCVFToFF(desired_s_opencvf, desired_s_ff);
    PrVector3 current_s_ff;
    transformFromOpenCVFToFF(current_s_opencvf, current_s_ff);

    PrVector3 error_s_ff = desired_s_ff - current_s_ff;

    float z = estimateCircleDepth(f, diameter_real, crcl);

    PrMatrix3 Jv;
    getImageJacobianCFToFF(Jv, current_s_ff[0], current_s_ff[1], z, f, diameter_real);

    PrMatrix3 Jv_inv;
    Jv.pseudoInverse(Jv_inv);

    //Compute the desired velocity of the feature in feature frame
    PrVector3 vel_f_ff = error_s_ff / t0;

    //Compute the desired velocity of the end effector in camera frame
    PrVector3 vel_ee_cf = Jv_inv*vel_f_ff;

    PrVector3 vel_ee_eef;
    transformVelocityFromCFToEEF(vel_ee_cf, vel_ee_eef);

    PrVector3 vel_ee_bf;
    transformVelocityFromEEFToBF(x, vel_ee_eef, vel_ee_bf);

    // compute the next EE position for the next timestep given the desired EE velocity:
    PrVector3 step_ee_bf = vel_ee_bf * dt;

    PrVector desired_ee_pose_bf = x;
    desired_ee_pose_bf[0] += step_ee_bf[0];
    desired_ee_pose_bf[1] += step_ee_bf[1];
    desired_ee_pose_bf[2] += step_ee_bf[2];

    //Constraint for the reachable workspace of the robot 
    double actual_workspace = sqrt(desired_ee_pose_bf[0] * desired_ee_pose_bf[0] + desired_ee_pose_bf[1] * desired_ee_pose_bf[1] + desired_ee_pose_bf[2] * desired_ee_pose_bf[2]);
    if (actual_workspace <= 0.85) {

    //Command the robot to go to the new desired position:
    sprintf(cmdbuf,"goto %.4f %.4f %.4f %.4f %.4f %.4f %.4f", desired_ee_pose_bf[0], desired_ee_pose_bf[1], desired_ee_pose_bf[2], 0.50, 0.50, -0.50, 0.50);

    putText(img,cmdbuf, cv::Point(5,50), FONT_HERSHEY_SIMPLEX, 0.3, CV_RGB(0,255,0), 1.2);
    }
}

