#ifndef _YOURSAMPLER_H_
#define _YOURSAMPLER_H_


#include <rl/plan/Sampler.h>
#include <random>

namespace rl
{
    namespace plan
    {
        /**
         * Uniform random sampling strategy.
         */
        class YourSampler : public Sampler
        {
        public:
            YourSampler();

            virtual ~YourSampler();

            ::rl::math::Vector generate();

            virtual void seed(const ::std::mt19937::result_type& value);

            ::rl::math::Vector* getStddev() const;
			
			void setStddev(::rl::math::Vector* stddev);
			
			::rl::math::Vector* stddev;

            ::rl::math::Vector generateCollisionFree();

            ::rl::math::Vector generateGaussian(::rl::math::Vector sampleq, double stddev);
			
			::rl::math::Real getRatio() const;
			
			void setRatio(const ::rl::math::Real& ratio);

            ::rl::math::Real ratio;

        protected:
            ::std::uniform_real_distribution< ::rl::math::Real>::result_type rand();

            ::std::uniform_real_distribution< ::rl::math::Real> randDistribution;

            ::std::normal_distribution<::rl::math::Real>::result_type gauss();
			
			::std::normal_distribution<::rl::math::Real> gaussDistribution;

            ::std::mt19937 randEngine;

        private:

        };
    }
}


#endif // _YOURSAMPLER_H_
